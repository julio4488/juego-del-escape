var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4f455d97-4b60-4b1e-8732-5cb30f9fd2c8","f26715a8-1e37-4be1-8633-d354eea65a25","3e837280-8eaa-49fa-a0a9-b09cad6650e1","c5ca0c15-cde9-4c2b-be01-93d2d035d3b6","ca6d7a08-8a43-418c-808c-206a2343e36b","a627282b-de00-4a46-b316-a2544dde9b17","23aaf595-5cbf-4c1c-a783-97c8281b0a6b","527b18d0-c9f4-40d5-949b-bf5f8069f414","73e829be-422b-4086-99a1-e298f712baeb","9cd24f43-0c29-4ad3-a8be-9e362756c1d9","64a7c03a-ccc5-43e9-a252-03666d16dde8","62b60e16-37b6-4a05-bab1-baba9b324738","8a7c01c9-d81c-49fa-8ccb-8ebd455d09ac","1dea4c36-c436-4e26-a9dd-b7d073be45fe","5fc38585-4b86-47d6-b9bd-7a46e1085672","9abe18ca-bbdd-4d16-8843-337de1037115","6aaa086c-52f0-4341-8206-58c17fee7b53","fe335e67-7b23-4697-9a44-091dbf53ed16","61aa9e6b-b677-40a6-92cf-f86b098023e2","0690cba0-60e4-4209-92fc-6ea31f242144","86f6987a-0e78-45e1-8ddc-9e5fd7e2d266"],"propsByKey":{"4f455d97-4b60-4b1e-8732-5cb30f9fd2c8":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"paEVhinNXNVu02qvyn9CRJSpDhCzrTXJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/4f455d97-4b60-4b1e-8732-5cb30f9fd2c8.png"},"f26715a8-1e37-4be1-8633-d354eea65a25":{"name":"alien1","sourceUrl":"assets/api/v1/animation-library/gamelab/yK6UXQtnemQ5itIdr3t5PWyn_FP7jFUf/category_fantasy/alienYellow_walk.png","frameSize":{"x":72,"y":88},"frameCount":2,"looping":true,"frameDelay":2,"version":"yK6UXQtnemQ5itIdr3t5PWyn_FP7jFUf","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":144,"y":88},"rootRelativePath":"assets/api/v1/animation-library/gamelab/yK6UXQtnemQ5itIdr3t5PWyn_FP7jFUf/category_fantasy/alienYellow_walk.png"},"3e837280-8eaa-49fa-a0a9-b09cad6650e1":{"name":"ovni","sourceUrl":"assets/api/v1/animation-library/gamelab/1NW0s4FKF54T3qL3gQC5gOgETMnxEZZw/category_icons/ufo.png","frameSize":{"x":386,"y":267},"frameCount":1,"looping":true,"frameDelay":2,"version":"1NW0s4FKF54T3qL3gQC5gOgETMnxEZZw","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":267},"rootRelativePath":"assets/api/v1/animation-library/gamelab/1NW0s4FKF54T3qL3gQC5gOgETMnxEZZw/category_icons/ufo.png"},"c5ca0c15-cde9-4c2b-be01-93d2d035d3b6":{"name":"alien","sourceUrl":"assets/api/v1/animation-library/gamelab/pGYLvPztt667XUxB0sylUZvmbhdkDTJo/category_fantasy/gameplayadventure_09.png","frameSize":{"x":387,"y":344},"frameCount":1,"looping":true,"frameDelay":2,"version":"pGYLvPztt667XUxB0sylUZvmbhdkDTJo","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":387,"y":344},"rootRelativePath":"assets/api/v1/animation-library/gamelab/pGYLvPztt667XUxB0sylUZvmbhdkDTJo/category_fantasy/gameplayadventure_09.png"},"ca6d7a08-8a43-418c-808c-206a2343e36b":{"name":"space","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"},"a627282b-de00-4a46-b316-a2544dde9b17":{"name":"planet1","sourceUrl":"assets/api/v1/animation-library/gamelab/tcyYeCxcLZ.bvfHrwoHi7j4qwj3J0kkv/category_icons/planet14.png","frameSize":{"x":400,"y":372},"frameCount":1,"looping":true,"frameDelay":2,"version":"tcyYeCxcLZ.bvfHrwoHi7j4qwj3J0kkv","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":372},"rootRelativePath":"assets/api/v1/animation-library/gamelab/tcyYeCxcLZ.bvfHrwoHi7j4qwj3J0kkv/category_icons/planet14.png"},"23aaf595-5cbf-4c1c-a783-97c8281b0a6b":{"name":"planet2","sourceUrl":"assets/api/v1/animation-library/gamelab/bkSmyTgb1jqA3TCS_I3VopIhBEXY4Jm1/category_icons/planet13.png","frameSize":{"x":400,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"bkSmyTgb1jqA3TCS_I3VopIhBEXY4Jm1","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bkSmyTgb1jqA3TCS_I3VopIhBEXY4Jm1/category_icons/planet13.png"},"527b18d0-c9f4-40d5-949b-bf5f8069f414":{"name":"planet3","sourceUrl":"assets/api/v1/animation-library/gamelab/uftJeLVlYsshEVa.ZLjPHV89eW8YxbCZ/category_icons/planet11.png","frameSize":{"x":396,"y":362},"frameCount":1,"looping":true,"frameDelay":2,"version":"uftJeLVlYsshEVa.ZLjPHV89eW8YxbCZ","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":362},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uftJeLVlYsshEVa.ZLjPHV89eW8YxbCZ/category_icons/planet11.png"},"73e829be-422b-4086-99a1-e298f712baeb":{"name":"planet4","sourceUrl":"assets/api/v1/animation-library/gamelab/MNXTe9Vzbt4fPkzUHwmt2Pbzfo4_Gw07/category_icons/planet04.png","frameSize":{"x":400,"y":366},"frameCount":1,"looping":true,"frameDelay":2,"version":"MNXTe9Vzbt4fPkzUHwmt2Pbzfo4_Gw07","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":366},"rootRelativePath":"assets/api/v1/animation-library/gamelab/MNXTe9Vzbt4fPkzUHwmt2Pbzfo4_Gw07/category_icons/planet04.png"},"9cd24f43-0c29-4ad3-a8be-9e362756c1d9":{"name":"planet5","sourceUrl":"assets/api/v1/animation-library/gamelab/T11WK4Za.d1YiZvBMHJVlywR8zjqws2d/category_icons/planet05.png","frameSize":{"x":400,"y":372},"frameCount":1,"looping":true,"frameDelay":2,"version":"T11WK4Za.d1YiZvBMHJVlywR8zjqws2d","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":372},"rootRelativePath":"assets/api/v1/animation-library/gamelab/T11WK4Za.d1YiZvBMHJVlywR8zjqws2d/category_icons/planet05.png"},"64a7c03a-ccc5-43e9-a252-03666d16dde8":{"name":"planet6","sourceUrl":"assets/api/v1/animation-library/gamelab/uvE6yyHtfv4XLjrsV6aH.QCTZvJjT16e/category_icons/planet10.png","frameSize":{"x":396,"y":348},"frameCount":1,"looping":true,"frameDelay":2,"version":"uvE6yyHtfv4XLjrsV6aH.QCTZvJjT16e","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":348},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uvE6yyHtfv4XLjrsV6aH.QCTZvJjT16e/category_icons/planet10.png"},"62b60e16-37b6-4a05-bab1-baba9b324738":{"name":"planet7","sourceUrl":"assets/api/v1/animation-library/gamelab/co2EZKS9g2HlsHn9RXUGDQnVqv7ZE_dr/category_icons/planet18.png","frameSize":{"x":384,"y":396},"frameCount":1,"looping":true,"frameDelay":2,"version":"co2EZKS9g2HlsHn9RXUGDQnVqv7ZE_dr","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":384,"y":396},"rootRelativePath":"assets/api/v1/animation-library/gamelab/co2EZKS9g2HlsHn9RXUGDQnVqv7ZE_dr/category_icons/planet18.png"},"8a7c01c9-d81c-49fa-8ccb-8ebd455d09ac":{"name":"planet8","sourceUrl":"assets/api/v1/animation-library/gamelab/nGOenE1WijfC4DHy9IQB7Isq7IVsds8K/category_icons/earth.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"nGOenE1WijfC4DHy9IQB7Isq7IVsds8K","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nGOenE1WijfC4DHy9IQB7Isq7IVsds8K/category_icons/earth.png"},"1dea4c36-c436-4e26-a9dd-b7d073be45fe":{"name":"planet1.1","sourceUrl":"assets/api/v1/animation-library/gamelab/nGOenE1WijfC4DHy9IQB7Isq7IVsds8K/category_icons/earth.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"nGOenE1WijfC4DHy9IQB7Isq7IVsds8K","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nGOenE1WijfC4DHy9IQB7Isq7IVsds8K/category_icons/earth.png"},"5fc38585-4b86-47d6-b9bd-7a46e1085672":{"name":"planet1.2","sourceUrl":"assets/api/v1/animation-library/gamelab/MNXTe9Vzbt4fPkzUHwmt2Pbzfo4_Gw07/category_icons/planet04.png","frameSize":{"x":400,"y":366},"frameCount":1,"looping":true,"frameDelay":2,"version":"MNXTe9Vzbt4fPkzUHwmt2Pbzfo4_Gw07","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":366},"rootRelativePath":"assets/api/v1/animation-library/gamelab/MNXTe9Vzbt4fPkzUHwmt2Pbzfo4_Gw07/category_icons/planet04.png"},"9abe18ca-bbdd-4d16-8843-337de1037115":{"name":"planet1.3","sourceUrl":"assets/api/v1/animation-library/gamelab/T11WK4Za.d1YiZvBMHJVlywR8zjqws2d/category_icons/planet05.png","frameSize":{"x":400,"y":372},"frameCount":1,"looping":true,"frameDelay":2,"version":"T11WK4Za.d1YiZvBMHJVlywR8zjqws2d","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":372},"rootRelativePath":"assets/api/v1/animation-library/gamelab/T11WK4Za.d1YiZvBMHJVlywR8zjqws2d/category_icons/planet05.png"},"6aaa086c-52f0-4341-8206-58c17fee7b53":{"name":"planet1.4","sourceUrl":"assets/api/v1/animation-library/gamelab/uvE6yyHtfv4XLjrsV6aH.QCTZvJjT16e/category_icons/planet10.png","frameSize":{"x":396,"y":348},"frameCount":1,"looping":true,"frameDelay":2,"version":"uvE6yyHtfv4XLjrsV6aH.QCTZvJjT16e","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":348},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uvE6yyHtfv4XLjrsV6aH.QCTZvJjT16e/category_icons/planet10.png"},"fe335e67-7b23-4697-9a44-091dbf53ed16":{"name":"planet1.5","sourceUrl":"assets/api/v1/animation-library/gamelab/uftJeLVlYsshEVa.ZLjPHV89eW8YxbCZ/category_icons/planet11.png","frameSize":{"x":396,"y":362},"frameCount":1,"looping":true,"frameDelay":2,"version":"uftJeLVlYsshEVa.ZLjPHV89eW8YxbCZ","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":362},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uftJeLVlYsshEVa.ZLjPHV89eW8YxbCZ/category_icons/planet11.png"},"61aa9e6b-b677-40a6-92cf-f86b098023e2":{"name":"planet1.6","sourceUrl":"assets/api/v1/animation-library/gamelab/bkSmyTgb1jqA3TCS_I3VopIhBEXY4Jm1/category_icons/planet13.png","frameSize":{"x":400,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"bkSmyTgb1jqA3TCS_I3VopIhBEXY4Jm1","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bkSmyTgb1jqA3TCS_I3VopIhBEXY4Jm1/category_icons/planet13.png"},"0690cba0-60e4-4209-92fc-6ea31f242144":{"name":"planet1.7","sourceUrl":"assets/api/v1/animation-library/gamelab/tcyYeCxcLZ.bvfHrwoHi7j4qwj3J0kkv/category_icons/planet14.png","frameSize":{"x":400,"y":372},"frameCount":1,"looping":true,"frameDelay":2,"version":"tcyYeCxcLZ.bvfHrwoHi7j4qwj3J0kkv","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":372},"rootRelativePath":"assets/api/v1/animation-library/gamelab/tcyYeCxcLZ.bvfHrwoHi7j4qwj3J0kkv/category_icons/planet14.png"},"86f6987a-0e78-45e1-8ddc-9e5fd7e2d266":{"name":"planet1.8","sourceUrl":"assets/api/v1/animation-library/gamelab/co2EZKS9g2HlsHn9RXUGDQnVqv7ZE_dr/category_icons/planet18.png","frameSize":{"x":384,"y":396},"frameCount":1,"looping":true,"frameDelay":2,"version":"co2EZKS9g2HlsHn9RXUGDQnVqv7ZE_dr","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":384,"y":396},"rootRelativePath":"assets/api/v1/animation-library/gamelab/co2EZKS9g2HlsHn9RXUGDQnVqv7ZE_dr/category_icons/planet18.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

   var space = createSprite (200,200);
space.setAnimation ("space");

var box1 = createSprite(25, 75, 50, 50);
box1.scale=0.1;
box1.setAnimation("planet1");

var box2 = createSprite(75, 75, 50, 50);
box2.scale=0.13;
box2.setAnimation("planet2");
box2.shapeColor="blue";

var box3 = createSprite(125, 75, 50, 50);
box3.scale=0.1;
box3.setAnimation("planet3");

var box4 = createSprite(175, 75, 50, 50);
box4.scale=0.1;
box4.setAnimation("planet4");

var box5 = createSprite(225, 75, 50, 50);
box5.scale=0.1;
box5.setAnimation("planet5");

var box6 = createSprite(275, 75, 50, 50);
box6.scale=0.1;
box6.setAnimation("planet6");

var box7 = createSprite(325, 75, 50, 50);
box7.scale=0.1;
box7.setAnimation("planet7");

var box8 = createSprite(375, 75, 50, 50);
box8.scale=0.1;
box8.setAnimation("planet8");

var box9 = createSprite(25, 125, 50, 50);
box9.scale=0.1;
box9.setAnimation("planet1.1");

var box10 = createSprite(75, 125, 50, 50);
box10.scale=0.13;
box10.setAnimation("planet1.2");


var box11 = createSprite(125, 125, 50, 50);
box11.scale=0.1;
box11.setAnimation("planet1.3");

var box12 = createSprite(175, 125, 50, 50);
box12.scale=0.1;
box12.setAnimation("planet1.4");

var box13 = createSprite(225, 125, 50, 50);
box13.scale=0.1;
box13.setAnimation("planet1.5");

var box14 = createSprite(275, 125, 50, 50);
box14.scale=0.1;
box14.setAnimation("planet1.6");

var box15 = createSprite(325, 125, 50, 50);
box15.scale=0.1;
box15.setAnimation("planet1.7");

var box16 = createSprite(375, 125, 50, 50);
box16.scale=0.1;
box16.setAnimation("planet1.8");



var score=0;

var paddle=createSprite(200,390,100,20);

paddle.scale=0.1;
paddle.setAnimation("ovni");

var ball=createSprite(200,200,20,20);

ball.scale=0.1;
ball.setAnimation("alien");

var gameState = "start";


function draw() {
  

  

  
if (gameState == "start") {
  


  
  fill ("white");
  textSize("35");
  text ("presiona enter para jugar",200,300);
  
  

  if (keyDown("enter")) {
    
  ball.velocityX=2;
  ball.velocityY=3;
  
  gameState="game";
  
  }

}

if (gameState== "game") {
  
 
  
    fill("green");
  textSize(25);
  text ("score: " + score , 30, 30);
  
 

 
  
  createEdgeSprites();

  paddle.x=World.mouseX;
  
 ball.bounceOff(topEdge);
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(paddle);
  
if (ball.isTouching(box1)) {
    
    box1.destroy();
    score=score+1;
  }
    
 if (ball.isTouching(box2)) {
   
   box2.destroy();
   score=score+1;
   
 }
if (ball.isTouching(box3)) {
     
     box3.destroy();
     score=score+1;
     
   }
      
if (ball.isTouching(box4)) {
  
  box4.destroy();
  score=score+1;
     
   }
      
  if (ball.isTouching(box5))    {
    
    box5.destroy();
    score=score+1;
    
  }
    
      if (ball.isTouching(box6))  {
        
        box6.destroy();
        score=score+1;
        
      }
  
  if (ball.isTouching(box7)) {
    
    box7.destroy();
    score=score+1;
    
  }
  
  if (ball.isTouching(box8)) {
    
    box8.destroy();
    score=score+1;
    
  }
  
  if(ball.isTouching(box9)) {
    
    box9.destroy();
    score=score+1;
    
  }
  
  if(ball.isTouching(box10)) {
    
    box10.destroy();
    score=score+1;
    
  }
  
  if(ball.isTouching(box11)) {
    
    box11.destroy();
    score=score+1;
    
  }
  
  if(ball.isTouching(box12)) {
    
    box12.destroy();
    score=score+1;
    
  }
  
  if(ball.isTouching(box13)) {
    
    box13.destroy();
    score=score+1;
    
  }
  
  if (ball.isTouching(box14)) {
    
    box14.destroy();
    score=score+1;
  }
  
  if (ball.isTouching(box15)) {
    
    box15.destroy();
    score=score+1;
    
  }
  
  if (ball.isTouching(box16)) {
    
    box16.destroy();
    score=score+1;
    
     }
    
  if (score==16 || ball.isTouching(bottomEdge)) {
    
    gameState="end";
  }
}

if (gameState== "end") {
  
  fill("green");
  textSize ("35");
  text ("game over", 110, 240);
  
  ball.velocityX=0;
  ball.velocityY=0;
  
}
  
  drawSprites();
  

}




// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
